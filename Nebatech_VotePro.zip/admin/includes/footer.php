<footer class="main-footer" style="background-color: #1A1F2B;">
    <div class="pull-right hidden-xs">
      <b>All rights reserved</b>
    </div>
    <strong>Copyright &copy; 2024 <a href="https://github.com/IAmAbdulHafiz/Nebatech_VotePro">Nebatech VotePro</a></strong>
</footer>